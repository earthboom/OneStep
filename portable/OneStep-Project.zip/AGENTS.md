## OneStep

For each new substantive task, read onestep-strategy/agents/vegabond-agent.md
and onestep-strategy/skills/vegabond-scout/SKILL.md relative to this project root.
Use onestep-strategy as the root for paths to OneStep procedures. Resolve
relative Markdown links from their containing document. Read only the procedures
needed for the task. Use this working project's instructions, sources and
stores first. Treat the bundled strategy as reference material. Report any
required checks you cannot perform.
