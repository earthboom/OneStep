---
name: vegabond-image
description: Use when creating, editing, or producing a consistent series of raster images, including realistic or stylized illustrations, cute mascots for stationery and stickers, game UI icons and controls, 2D game sprites, animated effects, and flipbooks with specific visual or delivery requirements.
---

# Vegabond Image

Use this specialist within OneStep create or revise. In Codex, use the available built-in `imagegen` skill and its execution instructions for image generation and edits. Use the [style and review examples](references/style-and-review.md) when the medium, composition, series consistency, typography, or output constraints warrant more detail.

When invoked directly for work that depends on an existing character or production specification, use [Scout's shared setup](../vegabond-scout/SKILL.md#frame-and-classify). Reuse the brief, or consult [knowledge](../vegabond-knowledge/SKILL.md) for the project's identity and review criteria. Verify supplier-specific dimensions against the applicable approved sheet. If a consequential specification is still missing, use the [research step](../vegabond-research/SKILL.md) within the available source scope and leave the dependent production check open. Self-contained visual requests can proceed directly.

## Define what the image must show

- For HUD, inventory or menu artwork, use the [game UI art guide](references/game-ui-art.md) to choose the asset layers, preserve geometry across states and inspect the result inside its target slot.
- From the original request, identify hard requirements, preferences, and delegated choices. Write a short internal set of observable acceptance checks for hard requirements. Include only checks relevant to the request. Preserve exact wording, quantities, attributes, locations, omissions, and delivery specs. Resolve left and right relative to the frame when that is what the user means. For multiple objects, tie each material, color, count, and position to its named object.
- Identify scene content and rendering medium independently. Describe a style with observable features such as light and texture, line and shape, brushwork, palette, or spatial rules. Keep the user's creative decisions and use their flexibility where they delegated it. A short clear request can go straight to generation. Ask one focused question when conflicting or missing information would materially change the result.
- For a stationery mascot, character sticker, expression set, memo pad illustration, or similar small-format character asset, use the [stationery character guide](references/stationery-characters.md). Identify what should make the character recognizable and check the finished art at its display size or in its physical product layout.
- When a person's pose, touch, expression or skin is central to the image, use [drawing people](references/drawing-people.md) to stage the moment and inspect the figure in the requested medium.
- When meaning, color treatment, or believability drives the brief, use the [visual direction questions](references/style-and-review.md#direct-and-test-the-reading). Choose the few cues that carry the request. Keep your chosen staging flexible unless the user specified it.
- When the user wants distinct visual ideas, asks for a less repetitive result, or delegates a choice that changes what the image communicates, use [creative exploration](references/creative-exploration.md). Preserve the brief's core and compare visible interpretations before settling on a direction.
- When a small accent must catch the eye against a larger material in colored light, [check both readings together](references/style-and-review.md#material-color-and-first-glance) before accepting a generation or color repair.
- For each input, name its role and the features it contributes. Distinguish an edit source from references for identity, layout, pose, rendering, or color. When two references overlap, state which one controls the relevant feature. For a series, use an approved frame or a shared identity reference and describe each frame as a standalone scene. State that frame's subject count separately from the series length whenever count matters.
- For an edit, write the change and the preservation conditions before calling the generator. Use the source or last accepted version as input. When exact composition is essential, use an available sketch or layout reference when it would resolve ambiguity.

## Generate and inspect

1. Translate checks into visual instructions. For a complex scene, use short labeled groups for the scene and composition, object-attribute relationships, visual treatment, and output constraints. Keep count-sensitive items distinct and visible. When an exact viewpoint matters, specify the camera relative to the subject or surface and the shapes or faces that should be visible. For a simple request, use a natural prompt. Give exact literal text with its location and line breaks. For open visual exploration, generate distinct candidates when the user would benefit from choosing between them.
2. Inspect the actual image against the original checks. Mark each as met, failed, or unverified. Verify counts, binding, spatial relationships, and viewpoint cues individually. When a frame has a strict subject count, scan the background as well as the foreground before comparing identity across the series. Compare exact text at readable magnification. Compare the edit beside its source for both the requested change and preservation. Check series identity against the shared reference and neighboring frames. Treat aesthetics and hard requirements as separate judgments.
3. Inspect the delivered file for requested format, pixel dimensions, aspect ratio, and real alpha transparency as applicable. When a necessary pixel size is unavailable directly, leave enough framing room and normalize canvas size or crop as appropriate. Reinspect placement, detail, and alpha after normalization. When exact text is essential and the output permits typographic layout, reserve space and render the supplied text as a separate layout layer. Export to the requested format and verify the final rendering.
4. Use the smallest correction that addresses the observed failure. If the same approach keeps missing an important condition, [match the repair to the failure](references/style-and-review.md#match-the-repair-to-the-failure). Compare the result with the last accepted source or layout, then recheck the failed condition and the nearby details the repair could affect. Report any remaining failed or unverified hard requirements and deliver the usable files with their locations.

For an expressive brief, describe what the delivered image communicates before comparing it with the intended reading. Cite a visible cue and flag plausible competing readings when they change the meaning. Repair a contradiction or a missing requested effect. An equally legible artistic choice can stand.

For a 2D game character portrait, gameplay image or animated sprite, use the [2D character asset guide](references/2d-game-characters.md) when defining the brief. Choose the requested deliverable, reuse character landmarks across views, and judge the result at its display size or playback speed.

For a 2D game effect or a sprite action that triggers one, use [drawing effects in motion](references/2d-effects-and-motion.md) to plan the key drawings, connect the effect to the gameplay event and review the exported layers in motion.

For an opening prop, a standalone burst, or windblown particles, use the [sprite production guide](references/2d-effects-and-motion.md#draw-a-prop-a-burst-or-an-animated-particle). Specify what moves within each cel, what moves through the game world, and what appears after playback ends.

## Shared review checkpoints

Apply [the shared review checkpoints](../vegabond-review/SKILL.md#review-checkpoints) using image criteria. When a consequential visual design or production brief is created or changed, review its requirements and feasibility before dependent generation; do not claim to inspect an image that does not yet exist. Before delivery, integrate the actual image/export checks above into the final review. Reuse source comparisons and valid knowledge/problem evidence; do not regenerate merely for optional taste differences.
