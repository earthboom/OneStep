---
name: vegabond-code-design
description: Use when software work needs architecture, ownership, lifecycle, interface, concurrency, persistence, or migration decisions, including gameplay framework design and independently extensible game content, or when a software design is the requested deliverable.
---

# Vegabond Code Design

Settle software design decisions for the calling operation or [vegabond-code](../vegabond-code/SKILL.md). Reuse its brief, environment, sources, and information brief. The caller owns execution and verification; design does not start a second workflow or certify working software. Follow the [agent instructions](../../agents/vegabond-agent.md) for document boundaries and common acceptance. Reading this skill does not spawn an agent.

If invoked directly, fill only missing context through [scout's shared setup](../vegabond-scout/SKILL.md#frame-and-classify) and [code's environment assessment](../vegabond-code/SKILL.md#identify-the-working-environment). For a design-only request, deliver the design and its supporting evidence without changing production code. Use isolated experiments only when authorized and needed to settle a decision.

For game architecture and technical choices, use the [game evidence reuse convention](../../knowledge/game/K-GAME-RESEARCH-USE.md), including on direct invocation. Reuse valid retrieved evidence, inspect prerequisites such as restorable state for rollback, and record adoption, conditional use or rejection against actual engine, platform and gameplay constraints. Return the selected entry IDs, implementation boundaries and proposed validation with the design.

When choosing a game's framework or changing how content is authored, registered, or composed across features, apply [gameplay framework and content design](references/gameplay-framework.md). Use its applicable parts for both new designs and revisions, and pass its checks to the implementation workflow.

When deciding how game data evolves, what a world loads or retains, how a renderer meets its budget, or what NPCs do offscreen, use the applicable [world runtime design guidance](references/world-lifecycle.md). Tie each chosen policy to a gameplay requirement and pass the preservation, transition and measurement conditions to implementation.

## Resolve the design

Use the shared [information-needs judgment](../vegabond-scout/references/information-needs.md) to test whether required guarantees, boundaries and counterexamples expose missing questions. Keep adopted contracts, conditional assumptions and rejected analogies attached to the choices they affect.

1. **Ground the decision.** Identify the decision to settle, required outcome, preservation conditions, and affected boundaries from the existing brief. Inspect relevant entry points, callers, data, tests, and project conventions. Refine source or prior-lesson questions through [knowledge](../vegabond-knowledge/SKILL.md) only when the information brief has a concrete gap. Keep required guarantees distinct from proposed tradeoffs; expose conflicting requirements or unavailable capabilities instead of silently weakening the goal.
2. **Define the shape.** State the relevant data model, state owner, invariants, lifecycle and interfaces before specifying implementation steps. Include failure behavior and, where material, concurrent access, retries, persistence, cleanup and integration boundaries. Use the language/framework's actual contracts. Resolve only what the task needs; a pure function need not acquire an artificial state machine.
3. **Choose with evidence.** Compare alternatives when there is a real tradeoff; do not invent several designs for an obvious local pattern. Explain the selected structure's fit, costs, and material rejected option. When an empirical uncertainty could overturn the choice, inspect evidence or run the smallest scoped prototype before dependent work. Mark an inaccessible required check blocked and an untested assumption uncertain; a plausible sketch is not runtime proof.
4. **Make it implementable and checkable.** Identify affected interfaces/callers, migration order and compatibility obligations when relevant. Link each load-bearing invariant or assumption to a concrete check, expected observation, and required environment. Set measurable budgets for performance/resource claims when those claims matter. Before returning a design or advancing dependent implementation, read and apply [design review](references/review.md): trace requirements to mechanisms and evidence, challenge relevant failure sequences, and repair contradictions. The review owns these detailed checks; the caller's software verification still applies to implementation.

## Return the decision

Apply the [shared reader-facing design guidance](../../agents/references/design-communication.md) when composing and handing back the result. Explain observable behavior and important failure cases before introducing types, storage fields or transaction details. Then connect the chosen shape/ownership, interfaces, implementation or migration units, evidence and checks to the decisions they support.

State which guarantees the design supports, which implementation checks remain, and which unresolved premises block named dependent work. A useful partial proposal is not a satisfied guarantee. The caller applies [code's verification procedure](../vegabond-code/references/verification.md) to the actual implementation and returns here only when evidence changes a design decision. Preserve valid context rather than redesigning everything after each failure.
